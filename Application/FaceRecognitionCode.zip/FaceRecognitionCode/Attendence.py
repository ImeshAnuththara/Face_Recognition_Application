import cv2
import  face_recognition
import numpy as np
import os
from datetime import datetime

path = "ImageAttendence"
images = []
classNames = []
myList = os.listdir(path)
print(myList)
for i in myList:
    currentImg = cv2.imread(f'{path}/{i}')
    images.append(currentImg)
    classNames.append(os.path.splitext(i)[0])
print(classNames)

def findEncodings(images):
    encodelist=[]
    for img in images:
        img =cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        encodeimg = face_recognition.face_encodings(img)[0]
        encodelist.append(encodeimg)
    return  encodelist

def Attendence(name):


    return name

NoImages=findEncodings(images)
print(len(NoImages))

cap = cv2.VideoCapture(0)

while True:
    success, img = cap.read()
    imgs = cv2.resize(img,(0,0),None,.25,.25)
    imgs = cv2.cvtColor(imgs,cv2.COLOR_BGR2RGB)

    faceCursorFrame = face_recognition.face_locations(imgs)
    encordeCursorFrame = face_recognition.face_encodings(imgs,faceCursorFrame)

    for encodeFace,FaceLocation in zip(encordeCursorFrame,faceCursorFrame):
        match = face_recognition.compare_faces(NoImages,encodeFace)
        faceDis = face_recognition.face_distance(NoImages,encodeFace)
        #print(faceDis)
        matchIndex=np.argmin(faceDis)

        if match[matchIndex]:
            name = classNames[matchIndex].upper()
            print(name)
            y1,x2,y2,x1 = FaceLocation
            y1, x2, y2, x1 = y1*4,x2*4,y2*4,x1*4
            cv2.rectangle(img,(x1,y1-30),(x2,y2),(0,255,0),2)
            #cv2.rectangle(img, (x1,y1-30), (x2, y2), (0, 255, 0),1)
            cv2.putText(img,name,(x1+6,y2-6),cv2.FONT_ITALIC,1,(255,255,255),1)


    cv2.imshow("Video",img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
