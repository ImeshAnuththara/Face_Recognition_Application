import cv2
import  face_recognition
import numpy as np

imgbil = face_recognition.load_image_file('Resource/bill_gates.jpg')
imgbil=cv2.cvtColor(imgbil,cv2.COLOR_BGR2RGB)
imgTest = face_recognition.load_image_file('Resource/test.jpg')
imgTest=cv2.cvtColor(imgTest,cv2.COLOR_BGR2RGB)

faceloc = face_recognition.face_locations(imgbil)[0]
encodebill = face_recognition.face_encodings(imgbil)[0]
cv2.rectangle(imgbil,(faceloc[3],faceloc[0]),(faceloc[1],faceloc[2]),(255,0,255),2)

facelocTest = face_recognition.face_locations(imgTest)[0]
encodeTest = face_recognition.face_encodings(imgTest)[0]
cv2.rectangle(imgTest,(facelocTest[3],facelocTest[0]),(facelocTest[1],facelocTest[2]),(255,0,255),2)

result = face_recognition.compare_faces([encodebill],encodeTest)
cv2.putText(imgTest,f'Bill Gates',(50,40),cv2.FONT_HERSHEY_SIMPLEX,0.3,(0,0,255),1)
print(result)
#print(faceloc)

cv2.imshow('bill Gates',imgbil)
cv2.imshow('Test Image',imgTest)
cv2.waitKey(0)



# web cam
#cap = cv2.VideoCapture(0)
#cap.set(3,640)
#cap.set(4,480)
#cap.set(10,10)


#while True:
#    success, img = cap.read()
#    cv2.imshow("Video",img)
#    if cv2.waitKey(1) & 0xFF ==ord('q'):
#       break

#cap = cv2.VideoCapture("Resource/doorlock.mp4")
#while True:
#    success, img = cap.read()
#    cv2.imshow("Video",img)
#    if cv2.waitKey(1) & 0xFF ==ord('q'):
#       break


#read Image according to this
# #import cv2
#img=cv2.imread("Resource/bill_gates.jpg")
#cv2.imshow("output",img)
#cv2.waitKey(0)